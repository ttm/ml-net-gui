# chrome extension for scrapping data for donation

To install, in chrome, click the hamburger menu, go to More tools -> Extensions. Enable “Developer mode” on the top-right and click “Load Unpacked Extension” button, now browse to the main directory where manifest.json is located, click ok.

To use, go to your friends page (in your profile, click friends). Than click on the extension badge (probably on chrome's top right corner). Wait until it asks you to save the file. Then, email it to me, I'll be happy to help with visualizing and analysing the networks you send me.

## fixme
make a different favicon?
read fixme block in the start of ./scripts/fb\_scrape.js
