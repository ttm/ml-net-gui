# chrome extension for scrapping data for donation

To use it, in chrome, click the hamburger menu, go to More tools -> Extensions. Enable “Developer mode” on the top-right and click “Load Unpacked Extension” button, now browse to the main directory where manifest.json is located, click ok.

## fixme
make a different favicon?
